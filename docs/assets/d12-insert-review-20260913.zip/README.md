# D12 / BT-60 insert-bay review files

Provisional hardware, not physical validation or flight clearance.

- Open print/D12-BT60-insert-X1C-review.3mf as a project in Bambu Studio: X1C, 0.4 mm, Textured PEI, PLA.
- candidate/cad/ contains the six printable STEP/STL parts and complete assembly/electronics approximations.
  Do not print the assembly, paper tube or electronics keepouts.
- candidate/ contains configuration, mass ledger, nominal flight reports, results and OpenRocket models.
- render/ contains actual CAD cutaway and exploded views; electronics details are approximations.

This is the nominal integrated insert candidate. The broader 288-case uncertainty study, comparisons, build guide,
sourcing and remaining physical checks are documented at https://brentwilkins.github.io/rocket-workbench/ .
All 192 planned dummy/logger uncertainty cases pass configured numeric gates, not a reliability probability.
No active control, physical retention qualification or printer operation is included.

Do not mix this configuration with the older V5/18 mm package. Inspect toolpaths and fit before any printing;
measure complete mass/CG and verify recovery before flight consideration.
